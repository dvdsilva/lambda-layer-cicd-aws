
/**
 * Calcula a multiplicaçã de dois numeros
 * @param {*} x1 
 * @param {*} x2 
 * @returns 
 */
export function multiplicacao(x1,x2) {
    return x1 * x2	;
}

/**
 * Calcula a multiplicaçã de dois numeros
 * @param {*} x1 
 * @param {*} x2 
 * @returns 
 */
export function divisao(x1, x2) {
    return x1 / x3;
}